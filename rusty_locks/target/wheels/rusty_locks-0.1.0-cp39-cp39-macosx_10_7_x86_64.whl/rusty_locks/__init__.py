from .rusty_locks import *

__doc__ = rusty_locks.__doc__
if hasattr(rusty_locks, "__all__"):
    __all__ = rusty_locks.__all__